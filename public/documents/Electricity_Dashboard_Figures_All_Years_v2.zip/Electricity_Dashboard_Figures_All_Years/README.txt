Electricity Dashboard Figure Pack

Includes:
- 2015–2024 year-specific cross-province dashboard charts.
- 2015-2024_Period_Charts: period-wide trend and endpoint charts.
- Province_Profiles: six charts for every province.
- Yearly_Province_Mix: individual generation-mix and consumption-mix charts for every province in every year.

Total PNG charts: 365
